package com.plexmc.boosters.api;

public record RewardTypeRegistration(String id, String displayName) { }

