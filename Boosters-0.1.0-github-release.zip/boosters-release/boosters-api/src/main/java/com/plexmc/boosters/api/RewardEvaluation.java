package com.plexmc.boosters.api;

import java.math.BigDecimal;
import java.util.Set;

public record RewardEvaluation(
        BigDecimal originalAmount,
        BigDecimal effectiveMultiplier,
        BigDecimal adjustedAmount,
        boolean applied,
        Set<String> appliedBoosterKeys) {
    public RewardEvaluation {
        appliedBoosterKeys = Set.copyOf(appliedBoosterKeys == null ? Set.of() : appliedBoosterKeys);
    }
}

