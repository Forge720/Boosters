package com.plexmc.boosters.api;

public record AssignmentResult(boolean success, boolean replaced, BoosterView booster, String message) {
    public static AssignmentResult failure(String message) {
        return new AssignmentResult(false, false, null, message);
    }
}

