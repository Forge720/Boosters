package com.plexmc.boosters.api;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

public record BoosterView(
        UUID player,
        boolean global,
        String rewardType,
        String id,
        BigDecimal multiplier,
        BoosterState state,
        Instant assignedAt,
        Instant activatedAt,
        Instant expiresAt) {
    public boolean permanent() {
        return expiresAt == null;
    }
}

