package com.plexmc.boosters.api;

public enum BoosterState {
    READY,
    ACTIVE,
    EXPIRED
}

