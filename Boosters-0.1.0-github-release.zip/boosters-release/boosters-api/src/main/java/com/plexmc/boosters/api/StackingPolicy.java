package com.plexmc.boosters.api;

public enum StackingPolicy {
    HIGHEST,
    ADDITIVE,
    MULTIPLICATIVE
}

