package com.plexmc.boosters.api;

import java.math.BigDecimal;
import java.util.Set;
import java.util.UUID;

public record RewardContext(
        UUID player,
        String rewardType,
        BigDecimal originalAmount,
        String source,
        String reason,
        String sourceTransactionId,
        boolean eligible,
        Set<String> appliedModifiers) {
    public RewardContext {
        if (player == null || rewardType == null || originalAmount == null) {
            throw new IllegalArgumentException("player, rewardType, and originalAmount are required");
        }
        if (originalAmount.signum() < 0) {
            throw new IllegalArgumentException("originalAmount cannot be negative");
        }
        appliedModifiers = Set.copyOf(appliedModifiers == null ? Set.of() : appliedModifiers);
    }

    public boolean hasModifier(String modifier) {
        return appliedModifiers.contains(modifier);
    }

    public RewardContext withModifier(String modifier) {
        var next = new java.util.HashSet<>(appliedModifiers);
        next.add(modifier);
        return new RewardContext(player, rewardType, originalAmount, source, reason, sourceTransactionId, eligible, next);
    }
}

