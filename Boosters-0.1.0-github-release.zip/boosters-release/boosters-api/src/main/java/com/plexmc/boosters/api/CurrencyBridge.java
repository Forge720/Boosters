package com.plexmc.boosters.api;

import java.util.Set;

/** Small service contract Currency.jar can register without depending on plugin internals. */
public interface CurrencyBridge {
    String primaryCurrencyId();
    Set<String> registeredCurrencyIds();
    boolean available();
}

