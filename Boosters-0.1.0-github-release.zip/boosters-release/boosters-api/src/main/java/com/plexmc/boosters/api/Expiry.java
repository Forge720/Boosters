package com.plexmc.boosters.api;

import java.time.Duration;
import java.util.Objects;

public record Expiry(Duration duration, boolean permanent) {
    public Expiry {
        if (!permanent && (duration == null || duration.isNegative() || duration.isZero())) {
            throw new IllegalArgumentException("A timed expiry must be positive");
        }
        if (permanent && duration != null) {
            throw new IllegalArgumentException("Permanent expiry cannot include a duration");
        }
    }

    public static Expiry timed(Duration duration) {
        return new Expiry(Objects.requireNonNull(duration, "duration"), false);
    }

    public static Expiry forever() {
        return new Expiry(null, true);
    }
}

