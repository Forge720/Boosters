package com.plexmc.boosters.api;

import java.math.BigDecimal;
import java.time.Duration;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletionStage;

public interface BoostersAPI {
    BigDecimal multiplier(UUID player, String rewardType);
    BigDecimal apply(UUID player, String rewardType, BigDecimal baseAmount);
    RewardEvaluation evaluate(RewardContext context);

    CompletionStage<AssignmentResult> setPersonal(UUID player, String id, String rewardType,
                                                    BigDecimal multiplier, Duration duration);
    CompletionStage<AssignmentResult> setPersonalPermanent(UUID player, String id, String rewardType,
                                                            BigDecimal multiplier);
    CompletionStage<AssignmentResult> setGlobal(String id, String rewardType,
                                                 BigDecimal multiplier, Duration duration);
    CompletionStage<AssignmentResult> setGlobalPermanent(String id, String rewardType,
                                                         BigDecimal multiplier);
    CompletionStage<AssignmentResult> give(UUID player, String presetId);
    CompletionStage<Boolean> activateReady(UUID player, String rewardType, String id);
    CompletionStage<Boolean> removePersonal(UUID player, String rewardType, String id);
    CompletionStage<Boolean> removeGlobal(String rewardType, String id);

    List<BoosterView> personal(UUID player);
    List<BoosterView> global();
    CompletionStage<Boolean> registerRewardType(RewardTypeRegistration registration);
    CompletionStage<Boolean> unregisterRewardType(String rewardType);
}

