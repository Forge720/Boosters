const mineflayer = require('/workspace/scratch/7d7eccdfeebb/integration-client/node_modules/mineflayer');
const bot = mineflayer.createBot({host:'127.0.0.1',port:Number(process.env.MC_PORT||25575),username:'BoostersTester',auth:'offline',version:'1.21.8'});
const messages=[]; let failed=false; let windows=0;
bot.on('messagestr',m=>{messages.push(m);console.log('[CHAT]',m)});
bot.on('windowOpen',w=>{windows++; console.log('[WINDOW]',w.title?.toString?.()||w.title,'slots',w.slots.length); console.log('[ITEMS]',w.slots.slice(0,27).map((x,i)=>x?`${i}:${x.name}:${x.displayName}`:null).filter(Boolean).join(' | '));});
const wait=ms=>new Promise(r=>setTimeout(r,ms));
function chat(x){console.log('[COMMAND]',x);bot.chat(x)}
async function expect(re,ms=6000){let end=Date.now()+ms;while(Date.now()<end){if(messages.some(x=>re.test(x)))return true;await wait(100)}console.error('[ASSERT]',re);failed=true;return false}
bot.once('spawn',async()=>{await wait(1500);chat('/boost set BoostersTester money 2x permanent rank');await expect(/Assigned/);chat('/boost set BoostersTester money 3x permanent rank');await expect(/Replaced/);chat('/boost list');await expect(/money.*rank.*3/);chat('/boost give BoostersTester money2x');await expect(/Assigned/);chat('/boost');await wait(700);if(windows<1)failed=true; if(bot.currentWindow){bot.closeWindow(bot.currentWindow);await wait(300)};chat('/boost admin');await wait(700);if(windows<2)failed=true; if(bot.currentWindow){await bot.clickWindow(0,0,0);await wait(300);chat('guiTest money 4x 5m');await expect(/Preset saved/)};chat('/boost give BoostersTester guiTest');await expect(/Assigned/);chat('/boost');await wait(700);if(windows<3)failed=true;console.log('[RESULT]',failed?'FAIL':'PASS');bot.quit();setTimeout(()=>process.exit(failed?1:0),500)});
bot.on('kicked',r=>{console.error('[KICKED]',r);failed=true});bot.on('error',e=>{console.error('[ERROR]',e);failed=true});

