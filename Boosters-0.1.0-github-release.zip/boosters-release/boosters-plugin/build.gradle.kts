plugins {
    `java-library`
}

dependencies {
    api(project(":boosters-api"))
    // Public API only; it is supplied by Currency.jar at runtime and is never shaded.
    compileOnly(files("../libs/currency-api-0.1.0.jar"))
    // Paper is supplied by the server. Keep its transitive graph out of this build's
    // resolution path; the API jar itself is cached/available in the target toolchain.
    compileOnly("io.papermc.paper:paper-api:1.21.11-R0.1-SNAPSHOT") { isTransitive = false }
    compileOnly("net.kyori:adventure-api:4.26.1") { isTransitive = false }
    compileOnly("net.kyori:adventure-key:4.26.1") { isTransitive = false }
    compileOnly("net.kyori:examination-api:1.3.0") { isTransitive = false }
    compileOnly("net.kyori:examination-string:1.3.0") { isTransitive = false }
    compileOnly("net.md-5:bungeecord-chat:1.21-R0.2-deprecated+build.21") { isTransitive = false }
    implementation("org.xerial:sqlite-jdbc:3.49.1.0")
    testImplementation(platform("org.junit:junit-bom:5.13.4"))
    testImplementation("org.junit.jupiter:junit-jupiter")
    testRuntimeOnly("org.junit.platform:junit-platform-launcher:1.13.4")
}

tasks.jar {
    archiveBaseName.set("Boosters-thin")
}

val fatStaging = layout.buildDirectory.dir("fat-staging")
val stageFat by tasks.registering(Sync::class) {
    dependsOn(tasks.named("classes"), project(":boosters-api").tasks.named("jar"))
    duplicatesStrategy = DuplicatesStrategy.EXCLUDE
    into(fatStaging)
    from(sourceSets.main.get().output)
    from(configurations.runtimeClasspath.map { files -> files.map { if (it.isDirectory) it else zipTree(it) } }) {
        exclude("META-INF/*.SF", "META-INF/*.RSA", "META-INF/*.DSA")
    }
}

val fatJar by tasks.registering(Jar::class) {
    dependsOn(stageFat)
    archiveBaseName.set("Boosters")
    archiveVersion.set("0.1.0")
    duplicatesStrategy = DuplicatesStrategy.EXCLUDE
    from(fatStaging)
}

tasks.named("build") { dependsOn(fatJar) }

