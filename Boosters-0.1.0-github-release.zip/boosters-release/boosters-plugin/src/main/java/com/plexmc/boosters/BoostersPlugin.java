package com.plexmc.boosters;

import com.plexmc.boosters.api.BoostersAPI;
import com.plexmc.boosters.booster.BoosterManager;
import com.plexmc.boosters.command.BoostCommand;
import com.plexmc.boosters.config.PresetRegistry;
import com.plexmc.boosters.gui.GuiManager;
import com.plexmc.boosters.integration.IntegrationManager;
import com.plexmc.boosters.integration.XpListener;
import com.plexmc.boosters.persistence.SQLiteStore;
import com.plexmc.boosters.registry.RewardRegistry;
import org.bukkit.Bukkit;
import org.bukkit.plugin.ServicePriority;
import org.bukkit.plugin.java.JavaPlugin;

import java.time.Clock;

public final class BoostersPlugin extends JavaPlugin {
    private BoosterManager manager; private PresetRegistry presets; private GuiManager gui; private IntegrationManager integrations;

    @Override public void onEnable() {
        try {
            RewardRegistry registry=new RewardRegistry(); presets=new PresetRegistry(this,registry); presets.load();
            SQLiteStore store=new SQLiteStore(getDataFolder().toPath());
            manager=new BoosterManager(store,registry,com.plexmc.boosters.api.StackingPolicy.valueOf(presets.stacking().toUpperCase()),presets.cap(),Clock.systemUTC());
            manager.setPresetResolver(presets::get); integrations=new IntegrationManager(this,manager); integrations.refresh();
            gui=new GuiManager(this,manager,presets,integrations); Bukkit.getPluginManager().registerEvents(gui,this); Bukkit.getPluginManager().registerEvents(new XpListener(manager,getLogger()),this);
            BoostCommand command=new BoostCommand(this,manager,presets,gui,integrations); getCommand("boost").setExecutor(command);getCommand("boost").setTabCompleter(command);
            Bukkit.getServicesManager().register(BoostersAPI.class,manager,this,ServicePriority.Normal);
            Bukkit.getScheduler().runTaskTimer(this,integrations::refresh,100L,100L); Bukkit.getScheduler().runTaskTimerAsynchronously(this,manager::expireAndCleanup,200L,200L);
            getLogger().info("Boosters 0.1 enabled; stacking="+manager.policy()+", cap="+manager.cap());
        } catch (Exception ex) { getLogger().severe("Boosters failed to enable: "+ex.getMessage()); getServer().getPluginManager().disablePlugin(this); }
    }

    @Override public void onDisable() {
        if(gui!=null)gui.closeAll(); if(manager!=null){Bukkit.getServicesManager().unregister(BoostersAPI.class,manager);try{manager.close();}catch(Exception ex){getLogger().severe("Boosters shutdown incomplete: "+ex.getMessage());}}
    }
}

