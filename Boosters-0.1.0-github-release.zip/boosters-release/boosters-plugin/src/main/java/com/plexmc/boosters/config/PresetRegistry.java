package com.plexmc.boosters.config;

import com.plexmc.boosters.booster.BoosterManager;
import com.plexmc.boosters.registry.RewardRegistry;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public final class PresetRegistry {
    private final JavaPlugin plugin;
    private final RewardRegistry rewards;
    private final Map<String, BoosterManager.PresetDefinition> presets = new ConcurrentHashMap<>();
    private volatile FileConfiguration lastValid;
    private volatile String stacking = "highest";
    private volatile BigDecimal cap = new BigDecimal("1000");
    private volatile boolean bossbar = true;

    public PresetRegistry(JavaPlugin plugin, RewardRegistry rewards) { this.plugin=plugin; this.rewards=rewards; }

    public synchronized void load() {
        plugin.saveDefaultConfig();
        FileConfiguration candidate = plugin.getConfig();
        try {
            String policy = candidate.getString("settings.stacking", "highest").toLowerCase(Locale.ROOT);
            if (!Set.of("highest", "additive", "multiplicative").contains(policy)) throw new IllegalArgumentException("settings.stacking must be highest, additive, or multiplicative");
            BigDecimal candidateCap = parseMultiplier(candidate.getString("settings.max-multiplier", "1000x"));
            if (candidateCap.compareTo(BigDecimal.ONE) < 0) throw new IllegalArgumentException("settings.max-multiplier must be >= 1x");
            Map<String, BoosterManager.PresetDefinition> parsed = new HashMap<>();
            ConfigurationSection section = candidate.getConfigurationSection("presets");
            if (section != null) for (String rawId : section.getKeys(false)) {
                String id = RewardRegistry.normalizeId(rawId);
                String type = rewards.canonical(Objects.requireNonNull(section.getString(rawId + ".type"), "presets." + rawId + ".type"));
                BigDecimal multiplier = parseMultiplier(Objects.requireNonNull(section.getString(rawId + ".multiplier"), "presets." + rawId + ".multiplier"));
                String rawDuration = Objects.requireNonNull(section.getString(rawId + ".duration"), "presets." + rawId + ".duration");
                boolean permanent = rawDuration.equalsIgnoreCase("permanent");
                Duration duration = permanent ? null : parseDuration(rawDuration);
                parsed.put(id, new BoosterManager.PresetDefinition(id, type, multiplier, duration, permanent));
            }
            presets.clear(); presets.putAll(parsed); stacking=policy; cap=candidateCap; bossbar=candidate.getBoolean("settings.bossbar", true); lastValid=candidate;
        } catch (RuntimeException ex) {
            if (lastValid == null) throw new IllegalStateException("Invalid config.yml: " + ex.getMessage(), ex);
            plugin.getLogger().severe("Rejected config.yml reload: " + ex.getMessage() + "; keeping previous valid configuration");
            plugin.reloadConfig();
        }
    }

    public Map<String, BoosterManager.PresetDefinition> all() { return Map.copyOf(presets); }
    public BoosterManager.PresetDefinition get(String id) { return presets.get(id.toLowerCase(Locale.ROOT)); }
    public String stacking() { return stacking; }
    public BigDecimal cap() { return cap; }
    public boolean bossbar() { return bossbar; }

    public synchronized void savePreset(BoosterManager.PresetDefinition preset) throws Exception {
        String id=RewardRegistry.normalizeId(preset.id()); rewards.canonical(preset.rewardType());
        FileConfiguration config = plugin.getConfig();
        String path="presets."+id;
        config.set(path+".type", rewards.canonical(preset.rewardType())); config.set(path+".multiplier", preset.multiplier().stripTrailingZeros().toPlainString()+"x");
        config.set(path+".duration", preset.permanent()?"permanent":formatDuration(preset.duration()));
        atomicSave(config); load();
    }

    public synchronized void delete(String id) throws Exception {
        plugin.getConfig().set("presets." + RewardRegistry.normalizeId(id), null); atomicSave(plugin.getConfig()); load();
    }

    private void atomicSave(FileConfiguration config) throws Exception {
        Files.createDirectories(plugin.getDataFolder().toPath());
        var target=plugin.getDataFolder().toPath().resolve("config.yml"); var temp=plugin.getDataFolder().toPath().resolve("config.yml.tmp");
        config.save(temp.toFile());
        try { Files.move(temp,target,StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.ATOMIC_MOVE); }
        catch (java.nio.file.AtomicMoveNotSupportedException ex) { Files.move(temp,target,StandardCopyOption.REPLACE_EXISTING); }
        plugin.reloadConfig();
    }

    public static BigDecimal parseMultiplier(String raw) {
        if (raw == null || raw.length()>32) throw new IllegalArgumentException("Invalid multiplier");
        String value=raw.trim().toLowerCase(Locale.ROOT); if (value.endsWith("x")) value=value.substring(0,value.length()-1);
        try { BigDecimal n=new BigDecimal(value); if (n.signum()<=0 || n.scale()>12 || n.compareTo(new BigDecimal("1000"))>0) throw new IllegalArgumentException("Multiplier must be 0<x<=1000 with max 12 decimals"); return n.stripTrailingZeros(); }
        catch (NumberFormatException ex) { throw new IllegalArgumentException("Invalid multiplier: "+raw); }
    }

    public static Duration parseDuration(String raw) {
        if (raw==null || raw.length()>24) throw new IllegalArgumentException("Invalid duration"); String v=raw.trim().toLowerCase(Locale.ROOT);
        if (!v.matches("[1-9][0-9]*(s|m|h|d)")) throw new IllegalArgumentException("Duration must use s, m, h, d, or permanent");
        long amount=Long.parseLong(v.substring(0,v.length()-1)); long seconds=switch(v.charAt(v.length()-1)){case 's'->amount;case 'm'->Math.multiplyExact(amount,60);case 'h'->Math.multiplyExact(amount,3600);case 'd'->Math.multiplyExact(amount,86400);default->throw new IllegalArgumentException();};
        return Duration.ofSeconds(seconds);
    }
    private static String formatDuration(Duration d) { long seconds=d.toSeconds(); if(seconds%86400==0)return seconds/86400+"d"; if(seconds%3600==0)return seconds/3600+"h"; if(seconds%60==0)return seconds/60+"m"; return seconds+"s"; }
}

