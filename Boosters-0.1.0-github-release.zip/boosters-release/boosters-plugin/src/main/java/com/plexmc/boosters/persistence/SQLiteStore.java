package com.plexmc.boosters.persistence;

import com.plexmc.boosters.api.BoosterState;
import com.plexmc.boosters.booster.BoosterRecord;

import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public final class SQLiteStore implements AutoCloseable {
    private final Connection connection;

    public SQLiteStore(Path dataFolder) throws Exception {
        Files.createDirectories(dataFolder);
        connection = DriverManager.getConnection("jdbc:sqlite:" + dataFolder.resolve("boosters.db"));
        try (Statement statement = connection.createStatement()) {
            statement.execute("PRAGMA journal_mode=WAL");
            statement.execute("PRAGMA synchronous=NORMAL");
            statement.execute("PRAGMA foreign_keys=ON");
        }
        migrate();
    }

    private void migrate() throws SQLException {
        try (Statement s = connection.createStatement()) {
            s.executeUpdate("CREATE TABLE IF NOT EXISTS schema_meta (version INTEGER NOT NULL)");
            try (ResultSet rs = s.executeQuery("SELECT COUNT(*) FROM schema_meta")) {
                if (rs.next() && rs.getInt(1) == 0) s.executeUpdate("INSERT INTO schema_meta(version) VALUES (1)");
            }
            s.executeUpdate("""
                CREATE TABLE IF NOT EXISTS personal_boosters (
                    player_uuid TEXT NOT NULL,
                    reward_type TEXT NOT NULL,
                    booster_id TEXT NOT NULL,
                    multiplier TEXT NOT NULL,
                    state TEXT NOT NULL,
                    assigned_at INTEGER NOT NULL,
                    activated_at INTEGER,
                    expires_at INTEGER,
                    duration_ms INTEGER,
                    PRIMARY KEY (player_uuid, reward_type, booster_id)
                )""");
            s.executeUpdate("""
                CREATE TABLE IF NOT EXISTS global_boosters (
                    reward_type TEXT NOT NULL,
                    booster_id TEXT NOT NULL,
                    multiplier TEXT NOT NULL,
                    state TEXT NOT NULL,
                    assigned_at INTEGER NOT NULL,
                    activated_at INTEGER NOT NULL,
                    expires_at INTEGER,
                    duration_ms INTEGER,
                    PRIMARY KEY (reward_type, booster_id)
                )""");
            try { s.executeUpdate("ALTER TABLE personal_boosters ADD COLUMN duration_ms INTEGER"); } catch (SQLException ignored) { }
            try { s.executeUpdate("ALTER TABLE global_boosters ADD COLUMN duration_ms INTEGER"); } catch (SQLException ignored) { }
        }
    }

    public synchronized void upsertPersonal(BoosterRecord r) throws SQLException {
        try (PreparedStatement p = connection.prepareStatement("""
            INSERT INTO personal_boosters(player_uuid,reward_type,booster_id,multiplier,state,assigned_at,activated_at,expires_at,duration_ms)
            VALUES(?,?,?,?,?,?,?,?,?)
            ON CONFLICT(player_uuid,reward_type,booster_id) DO UPDATE SET multiplier=excluded.multiplier,state=excluded.state,
            assigned_at=excluded.assigned_at,activated_at=excluded.activated_at,expires_at=excluded.expires_at,duration_ms=excluded.duration_ms""")) {
            p.setString(1, r.player().toString()); p.setString(2, r.rewardType()); p.setString(3, r.id());
            p.setString(4, r.multiplier().toPlainString()); p.setString(5, r.state().name()); p.setLong(6, r.assignedAt());
            if (r.activatedAt() == null) p.setNull(7, Types.INTEGER); else p.setLong(7, r.activatedAt());
            if (r.expiresAt() == null) p.setNull(8, Types.INTEGER); else p.setLong(8, r.expiresAt());
            if (r.durationMillis() == null) p.setNull(9, Types.INTEGER); else p.setLong(9, r.durationMillis());
            p.executeUpdate();
        }
    }

    public synchronized void upsertGlobal(BoosterRecord r) throws SQLException {
        try (PreparedStatement p = connection.prepareStatement("""
            INSERT INTO global_boosters(reward_type,booster_id,multiplier,state,assigned_at,activated_at,expires_at,duration_ms)
            VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(reward_type,booster_id) DO UPDATE SET multiplier=excluded.multiplier,
            state=excluded.state,assigned_at=excluded.assigned_at,activated_at=excluded.activated_at,expires_at=excluded.expires_at,duration_ms=excluded.duration_ms""")) {
            p.setString(1, r.rewardType()); p.setString(2, r.id()); p.setString(3, r.multiplier().toPlainString());
            p.setString(4, r.state().name()); p.setLong(5, r.assignedAt()); p.setLong(6, r.activatedAt());
            if (r.expiresAt() == null) p.setNull(7, Types.INTEGER); else p.setLong(7, r.expiresAt());
            if (r.durationMillis() == null) p.setNull(8, Types.INTEGER); else p.setLong(8, r.durationMillis());
            p.executeUpdate();
        }
    }

    public synchronized void deletePersonal(UUID player, String type, String id) throws SQLException {
        try (PreparedStatement p = connection.prepareStatement("DELETE FROM personal_boosters WHERE player_uuid=? AND reward_type=? AND booster_id=?")) {
            p.setString(1, player.toString()); p.setString(2, type); p.setString(3, id); p.executeUpdate();
        }
    }

    public synchronized void deleteGlobal(String type, String id) throws SQLException {
        try (PreparedStatement p = connection.prepareStatement("DELETE FROM global_boosters WHERE reward_type=? AND booster_id=?")) {
            p.setString(1, type); p.setString(2, id); p.executeUpdate();
        }
    }

    public synchronized List<BoosterRecord> loadAll(long now) throws SQLException {
        List<BoosterRecord> out = new ArrayList<>();
        try (Statement s = connection.createStatement(); ResultSet rs = s.executeQuery("SELECT * FROM personal_boosters")) {
            while (rs.next()) { try { out.add(readPersonal(rs, now)); } catch (RuntimeException ignored) { } }
        }
        try (Statement s = connection.createStatement(); ResultSet rs = s.executeQuery("SELECT * FROM global_boosters")) {
            while (rs.next()) { try { out.add(readGlobal(rs, now)); } catch (RuntimeException ignored) { } }
        }
        return out;
    }

    private BoosterRecord readPersonal(ResultSet rs, long now) throws SQLException {
        Long expires = number(rs.getObject("expires_at")); Long duration = number(rs.getObject("duration_ms"));
        BoosterState state = BoosterState.valueOf(rs.getString("state"));
        if (expires != null && expires <= now && state == BoosterState.ACTIVE) state = BoosterState.EXPIRED;
        return new BoosterRecord(UUID.fromString(rs.getString("player_uuid")), false, rs.getString("reward_type"), rs.getString("booster_id"),
                new BigDecimal(rs.getString("multiplier")), state, rs.getLong("assigned_at"), number(rs.getObject("activated_at")), expires, duration);
    }

    private BoosterRecord readGlobal(ResultSet rs, long now) throws SQLException {
        Long expires = number(rs.getObject("expires_at")); Long duration = number(rs.getObject("duration_ms"));
        BoosterState state = BoosterState.valueOf(rs.getString("state"));
        if (expires != null && expires <= now && state == BoosterState.ACTIVE) state = BoosterState.EXPIRED;
        return new BoosterRecord(null, true, rs.getString("reward_type"), rs.getString("booster_id"),
                new BigDecimal(rs.getString("multiplier")), state, rs.getLong("assigned_at"), rs.getLong("activated_at"), expires, duration);
    }

    private static Long number(Object value) { return value == null ? null : ((Number) value).longValue(); }

    public synchronized void cleanupExpired(long now) throws SQLException {
        try (PreparedStatement p = connection.prepareStatement("DELETE FROM personal_boosters WHERE state='ACTIVE' AND expires_at IS NOT NULL AND expires_at<=?")) {
            p.setLong(1, now); p.executeUpdate();
        }
        try (PreparedStatement p = connection.prepareStatement("DELETE FROM global_boosters WHERE state='ACTIVE' AND expires_at IS NOT NULL AND expires_at<=?")) {
            p.setLong(1, now); p.executeUpdate();
        }
    }

    @Override public synchronized void close() throws SQLException { connection.close(); }
}

