package com.plexmc.boosters.integration;

import com.plexmc.boosters.booster.BoosterManager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerExpChangeEvent;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.concurrent.atomic.AtomicLong;
import java.util.logging.Logger;

public final class XpListener implements Listener {
    private final BoosterManager manager;
    private final Logger logger;
    private final AtomicLong lastDiagnostic = new AtomicLong();

    public XpListener(BoosterManager manager, Logger logger) { this.manager=manager; this.logger=logger; }

    @EventHandler(priority = EventPriority.NORMAL, ignoreCancelled = true)
    public void onExperience(PlayerExpChangeEvent event) {
        int original = event.getAmount();
        if (original <= 0) return;
        try {
            BigDecimal result = BigDecimal.valueOf(original).multiply(manager.multiplier(event.getPlayer().getUniqueId(), "xp"));
            if (result.compareTo(BigDecimal.valueOf(Integer.MAX_VALUE)) > 0) {
                diagnostic("XP result exceeded integer bounds; preserving original amount");
                return;
            }
            event.setAmount(result.setScale(0, RoundingMode.HALF_UP).intValueExact());
        } catch (RuntimeException ex) {
            diagnostic("XP multiplier failed safely: " + ex.getMessage());
        }
    }

    private void diagnostic(String message) {
        long now=System.currentTimeMillis(); long previous=lastDiagnostic.get();
        if (now-previous>60_000 && lastDiagnostic.compareAndSet(previous, now)) managerDiagnostics(message);
    }
    private void managerDiagnostics(String message) { logger.warning(message); }
}

