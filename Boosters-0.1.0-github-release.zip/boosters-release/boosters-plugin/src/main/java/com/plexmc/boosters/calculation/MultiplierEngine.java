package com.plexmc.boosters.calculation;

import com.plexmc.boosters.api.StackingPolicy;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.Collection;

public final class MultiplierEngine {
    private static final BigDecimal ONE = BigDecimal.ONE;
    private static final MathContext MC = new MathContext(80, RoundingMode.HALF_UP);

    private MultiplierEngine() { }

    public static BigDecimal effective(Collection<BigDecimal> values, StackingPolicy policy, BigDecimal cap) {
        if (values == null || values.isEmpty()) return ONE;
        BigDecimal result;
        switch (policy) {
            case HIGHEST -> result = values.stream().max(BigDecimal::compareTo).orElse(ONE);
            case ADDITIVE -> {
                result = ONE;
                for (BigDecimal value : values) result = result.add(value.subtract(ONE, MC), MC);
            }
            case MULTIPLICATIVE -> {
                result = ONE;
                for (BigDecimal value : values) result = result.multiply(value, MC);
            }
            default -> throw new IllegalStateException("Unhandled policy: " + policy);
        }
        if (result.compareTo(ONE) < 0) result = ONE;
        return result.min(cap).stripTrailingZeros();
    }

    public static BigDecimal multiply(BigDecimal base, BigDecimal multiplier) {
        if (base == null || multiplier == null) throw new IllegalArgumentException("Amounts are required");
        if (base.signum() <= 0) return base;
        return base.multiply(multiplier, MC).stripTrailingZeros();
    }
}

