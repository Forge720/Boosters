package com.plexmc.boosters.integration;

import com.plexmc.boosters.api.CurrencyBridge;
import net.plexmc.currency.api.CurrencyDefinition;
import net.plexmc.currency.api.CurrencyService;
import net.plexmc.currency.api.ServiceState;
import org.bukkit.Bukkit;

import java.util.Set;
import java.util.stream.Collectors;

/** Adapter loaded only when Currency.jar and its public API are available. */
public final class CurrencyApiIntegration implements CurrencyBridge {
    private final CurrencyService service;

    public CurrencyApiIntegration() {
        service = Bukkit.getServicesManager().load(CurrencyService.class);
        if (service == null) throw new IllegalStateException("CurrencyService is not registered");
    }

    @Override public String primaryCurrencyId() { return service.currency("money").map(CurrencyDefinition::id).orElse(null); }
    @Override public Set<String> registeredCurrencyIds() {
        return service.currencies().stream().filter(CurrencyDefinition::enabled).map(CurrencyDefinition::id).collect(Collectors.toUnmodifiableSet());
    }
    @Override public boolean available() { return service.state() == ServiceState.READY; }
}

