package com.plexmc.boosters.registry;

import com.plexmc.boosters.api.CurrencyBridge;
import com.plexmc.boosters.api.RewardTypeRegistration;

import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public final class RewardRegistry {
    private final Map<String, RewardTypeRegistration> custom = new ConcurrentHashMap<>();
    private final Set<String> currencies = ConcurrentHashMap.newKeySet();
    private volatile String primaryCurrency;
    private volatile boolean currencyAvailable;

    public RewardRegistry() {
        currencies.add("money");
    }

    public String canonical(String raw) {
        if (raw == null || raw.isBlank()) throw new IllegalArgumentException("Reward type is required");
        String type = raw.trim().toLowerCase(Locale.ROOT);
        if (type.equals("xp")) return "xp";
        if (type.equals("money")) return "money";
        if (type.startsWith("currency:")) {
            String id = normalizeId(type.substring("currency:".length()));
            if (id.equals("money") || (primaryCurrency != null && id.equals(primaryCurrency))) return "money";
            return "currency:" + id;
        }
        if (custom.containsKey(type)) return type;
        throw new IllegalArgumentException("Unknown reward type: " + raw);
    }

    public void register(RewardTypeRegistration registration) {
        String id = normalizeId(registration.id());
        if (id.equals("money") || id.equals("xp") || id.startsWith("currency:")) {
            throw new IllegalArgumentException("Reserved reward type: " + id);
        }
        custom.put(id, new RewardTypeRegistration(id, registration.displayName()));
    }

    public void unregister(String id) {
        custom.remove(normalizeId(id));
    }

    public Set<String> types() {
        var result = ConcurrentHashMap.<String>newKeySet();
        result.add("money"); result.add("xp");
        if (currencyAvailable) currencies.forEach(c -> result.add(c.equals("money") ? "money" : "currency:" + c));
        result.addAll(custom.keySet());
        return Set.copyOf(result);
    }

    public boolean available(String canonicalType) {
        if (canonicalType.equals("money") || canonicalType.equals("xp") || custom.containsKey(canonicalType)) return true;
        return currencyAvailable && canonicalType.startsWith("currency:") && currencies.contains(canonicalType.substring("currency:".length()));
    }

    public void refreshCurrencyBridge(CurrencyBridge bridge) {
        currencies.removeIf(id -> !id.equals("money"));
        primaryCurrency = null;
        currencyAvailable = bridge != null && bridge.available();
        if (!currencyAvailable) return;
        String primary = bridge.primaryCurrencyId();
        if (primary != null) primaryCurrency = normalizeId(primary.replaceFirst("^currency:", ""));
        for (String id : bridge.registeredCurrencyIds()) {
            if (id != null && !id.isBlank()) currencies.add(normalizeId(id.replaceFirst("^currency:", "")));
        }
    }

    public static String normalizeId(String raw) {
        if (raw == null) throw new IllegalArgumentException("ID is required");
        String id = raw.trim().toLowerCase(Locale.ROOT);
        if (id.isBlank() || id.length() > 64 || !id.matches("[a-z0-9][a-z0-9_-]*")) {
            throw new IllegalArgumentException("Invalid identifier: " + raw);
        }
        return id;
    }
}

