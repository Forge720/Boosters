package com.plexmc.boosters.command;

import com.plexmc.boosters.booster.BoosterManager;
import com.plexmc.boosters.config.PresetRegistry;
import com.plexmc.boosters.gui.GuiManager;
import com.plexmc.boosters.integration.IntegrationManager;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.math.BigDecimal;
import java.time.Duration;
import java.util.*;
import java.util.stream.Collectors;

public final class BoostCommand implements CommandExecutor, TabCompleter {
    private final JavaPlugin plugin; private final BoosterManager manager; private final PresetRegistry presets; private final GuiManager gui; private final IntegrationManager integrations;
    public BoostCommand(JavaPlugin plugin,BoosterManager manager,PresetRegistry presets,GuiManager gui,IntegrationManager integrations){this.plugin=plugin;this.manager=manager;this.presets=presets;this.gui=gui;this.integrations=integrations;}
    @Override public boolean onCommand(CommandSender sender,Command command,String label,String[] args){
        if(args.length==0){if(!(sender instanceof Player p)){sender.sendMessage("/boost list or /boost admin");return true;}if(!p.hasPermission("boosters.use")){sender.sendMessage("§cNo permission.");return true;}gui.openPlayer(p);return true;}
        String sub=args[0].toLowerCase(Locale.ROOT);
        if(sub.equals("list")){return list(sender,args);}
        if(sub.equals("admin")){if(!admin(sender))return true;if(sender instanceof Player p)gui.openAdmin(p);else sender.sendMessage("Use admin subcommands from console.");return true;}
        if(!admin(sender))return true;
        try{switch(sub){case "give"->give(sender,args);case "set"->set(sender,args);case "global"->global(sender,args);case "remove"->remove(sender,args);case "reload"->reload(sender);default->usage(sender);} }catch(Exception ex){sender.sendMessage("§c"+ex.getMessage());}return true;
    }
    private boolean list(CommandSender s,String[] a){if(a.length==1&&s instanceof Player p){manager.personal(p.getUniqueId()).forEach(v->s.sendMessage(line(v)));manager.global().forEach(v->s.sendMessage("§dGLOBAL "+line(v)));return true;}if(!admin(s))return true;if(a.length<2){usage(s);return true;}if(a[1].equalsIgnoreCase("global")){manager.global().forEach(v->s.sendMessage("§dGLOBAL "+line(v)));return true;}try{UUID u=resolve(a[1]);manager.personal(u).forEach(v->s.sendMessage(line(v)));}catch(Exception ex){s.sendMessage("§c"+ex.getMessage());}return true;}
    private String line(com.plexmc.boosters.api.BoosterView v){return "§f"+v.rewardType()+" §7"+v.id()+" §e"+v.multiplier()+"x §7"+v.state()+(v.expiresAt()==null?" permanent":" until "+v.expiresAt());}
    private void give(CommandSender s,String[] a){if(a.length!=3){usage(s);return;}UUID u=resolve(a[1]);var p=presets.get(a[2]);if(p==null)throw new IllegalArgumentException("Unknown preset: "+a[2]);manager.givePreset(u,p).whenComplete((r,e)->reply(s,e,r));}
    private void set(CommandSender s,String[] a){if(a.length<5||a.length>6){usage(s);return;}UUID u=resolve(a[1]);BigDecimal m=PresetRegistry.parseMultiplier(a[3]);String id=a.length==6?a[5]:"default";if(a[4].equalsIgnoreCase("permanent"))manager.setPersonalPermanent(u,id,a[2],m).whenComplete((r,e)->reply(s,e,r));else manager.setPersonal(u,id,a[2],m,PresetRegistry.parseDuration(a[4])).whenComplete((r,e)->reply(s,e,r));}
    private void global(CommandSender s,String[] a){if(a.length<4||a.length>5){usage(s);return;}BigDecimal m=PresetRegistry.parseMultiplier(a[2]);String id=a.length==5?a[4]:"default";if(a[3].equalsIgnoreCase("permanent"))manager.setGlobalPermanent(id,a[1],m).whenComplete((r,e)->reply(s,e,r));else manager.setGlobal(id,a[1],m,PresetRegistry.parseDuration(a[3])).whenComplete((r,e)->reply(s,e,r));}
    private void remove(CommandSender s,String[] a){if(a.length<3||a.length>4){usage(s);return;}if(a[1].equalsIgnoreCase("global")){manager.removeGlobal(a[2],a.length==4?a[3]:"default").whenComplete((ok,e)->simple(s,ok,e));}else{UUID u=resolve(a[1]);manager.removePersonal(u,a[2],a.length==4?a[3]:"default").whenComplete((ok,e)->simple(s,ok,e));}}
    private void reload(CommandSender s){try{presets.load();manager.setPolicy(com.plexmc.boosters.api.StackingPolicy.valueOf(presets.stacking().toUpperCase(Locale.ROOT)),presets.cap());integrations.refresh();s.sendMessage("§aBoosters configuration reloaded.");}catch(Exception ex){s.sendMessage("§cReload rejected: "+ex.getMessage());}}
    private void reply(CommandSender s,Throwable e,com.plexmc.boosters.api.AssignmentResult r){Bukkit.getScheduler().runTask(plugin,()->s.sendMessage(e!=null?"§cMutation failed: "+e.getMessage():r.success()?"§a"+r.message():"§c"+r.message()));}
    private void simple(CommandSender s,Boolean ok,Throwable e){Bukkit.getScheduler().runTask(plugin,()->s.sendMessage(e!=null?"§cMutation failed: "+e.getMessage():Boolean.TRUE.equals(ok)?"§aRemoved.":"§cAssignment not found."));}
    private boolean admin(CommandSender s){if(!s.hasPermission("boosters.admin")){s.sendMessage("§cNo permission.");return false;}return true;}
    private UUID resolve(String raw){try{return UUID.fromString(raw);}catch(IllegalArgumentException ignored){}Player online=Bukkit.getPlayerExact(raw);if(online!=null)return online.getUniqueId();OfflinePlayer cached=Bukkit.getOfflinePlayerIfCached(raw);if(cached!=null)return cached.getUniqueId();throw new IllegalArgumentException("Use an online/cached player name or UUID.");}
    private void usage(CommandSender s){s.sendMessage("§e/boost [list|admin]");s.sendMessage("§e/boost give <player> <preset>");s.sendMessage("§e/boost set <player> <type> <multiplier> <duration|permanent> [id]");s.sendMessage("§e/boost global <type> <multiplier> <duration|permanent> [id]");s.sendMessage("§e/boost remove <player|global> <type> [id]");}
    @Override public List<String> onTabComplete(CommandSender sender,Command command,String alias,String[] args){if(args.length==1)return List.of("list","admin","give","set","global","remove","reload").stream().filter(x->x.startsWith(args[0].toLowerCase(Locale.ROOT))).toList();if(args[0].equalsIgnoreCase("give")&&args.length==3)return presets.all().keySet().stream().filter(x->x.startsWith(args[2].toLowerCase(Locale.ROOT))).toList();if((args[0].equalsIgnoreCase("set")||args[0].equalsIgnoreCase("global"))&&args.length==3)return manager.registry().types().stream().filter(x->x.startsWith(args[2].toLowerCase(Locale.ROOT))).sorted().toList();if(args[0].equalsIgnoreCase("set")&&args.length==5)return List.of("30m","1h","1d","permanent");if(args[0].equalsIgnoreCase("global")&&args.length==4)return List.of("30m","1h","1d","permanent");return List.of();}
}

