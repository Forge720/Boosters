package com.plexmc.boosters.booster;

import com.plexmc.boosters.api.BoosterState;
import com.plexmc.boosters.api.BoosterView;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

public record BoosterRecord(
        UUID player,
        boolean global,
        String rewardType,
        String id,
        BigDecimal multiplier,
        BoosterState state,
        long assignedAt,
        Long activatedAt,
        Long expiresAt,
        Long durationMillis) {
    public boolean activeAt(long now) {
        return state == BoosterState.ACTIVE && (expiresAt == null || expiresAt > now);
    }

    public BoosterView view() {
        return new BoosterView(player, global, rewardType, id, multiplier, state,
                Instant.ofEpochMilli(assignedAt), activatedAt == null ? null : Instant.ofEpochMilli(activatedAt),
                expiresAt == null ? null : Instant.ofEpochMilli(expiresAt));
    }

    public String identity() {
        return (global ? "global" : player.toString()) + ":" + rewardType + ":" + id;
    }
}

