package com.plexmc.boosters.integration;

import com.plexmc.boosters.api.BoostersAPI;
import com.plexmc.boosters.api.RewardContext;
import com.plexmc.boosters.api.RewardEvaluation;
import net.plexmc.currency.api.CurrencyAmount;
import net.plexmc.currency.api.CurrencyService;
import net.plexmc.currency.api.OperationContext;
import net.plexmc.currency.api.TransactionResult;

import java.util.concurrent.CompletionStage;

/** Explicit Currency.jar producer adapter; it never intercepts arbitrary credits. */
public final class CurrencyRewardAdapter {
    private CurrencyRewardAdapter() { }

    public static CompletionStage<TransactionResult> creditEligible(
            CurrencyService currency, BoostersAPI boosters, RewardContext context,
            String operationId, String sourcePlugin, String reason) {
        if (!context.eligible() || context.originalAmount().signum() <= 0) {
            throw new IllegalArgumentException("Only positive eligible rewards may be credited");
        }
        String currencyId = context.rewardType().equals("money")
                ? "money" : context.rewardType().startsWith("currency:")
                ? context.rewardType().substring("currency:".length()) : context.rewardType();
        RewardEvaluation evaluation = boosters.evaluate(context);
        CurrencyAmount amount = currency.parse(currencyId, evaluation.adjustedAmount().toPlainString());
        return currency.credit(context.player(), amount, OperationContext.of(sourcePlugin, reason, operationId));
    }
}

