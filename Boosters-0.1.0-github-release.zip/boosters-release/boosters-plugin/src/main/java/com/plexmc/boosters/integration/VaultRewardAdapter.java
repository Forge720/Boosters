package com.plexmc.boosters.integration;

import com.plexmc.boosters.api.BoostersAPI;
import com.plexmc.boosters.api.RewardContext;
import com.plexmc.boosters.api.RewardEvaluation;
import org.bukkit.OfflinePlayer;

import java.lang.reflect.Method;
import java.math.BigDecimal;

/** Optional reflective Vault adapter. It never intercepts deposits globally. */
public final class VaultRewardAdapter {
    private final BoostersAPI boosters;
    public VaultRewardAdapter(BoostersAPI boosters) { this.boosters=boosters; }

    public boolean depositEligible(Object economy, OfflinePlayer player, BigDecimal original, String source, String reason) throws Exception {
        if (economy==null||player==null||original==null||original.signum()<0) throw new IllegalArgumentException("Invalid Vault reward");
        RewardContext context=new RewardContext(player.getUniqueId(),"money",original,source,reason,null,true,java.util.Set.of());
        RewardEvaluation evaluation=boosters.evaluate(context);
        double amount=evaluation.adjustedAmount().doubleValue();
        if(!Double.isFinite(amount)||amount<0||new BigDecimal(Double.toString(amount)).compareTo(evaluation.adjustedAmount())!=0) throw new IllegalArgumentException("Reward cannot be represented safely by Vault double precision");
        Method deposit=java.util.Arrays.stream(economy.getClass().getMethods()).filter(m->m.getName().equals("depositPlayer")&&m.getParameterCount()==2).findFirst().orElseThrow(()->new NoSuchMethodException("depositPlayer(OfflinePlayer,double)"));
        Object response=deposit.invoke(economy,player,amount);
        Method success=response.getClass().getMethod("transactionSuccess");
        return Boolean.TRUE.equals(success.invoke(response));
    }
}

