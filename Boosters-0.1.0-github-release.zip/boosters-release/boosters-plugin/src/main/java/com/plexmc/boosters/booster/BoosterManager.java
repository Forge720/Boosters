package com.plexmc.boosters.booster;

import com.plexmc.boosters.api.*;
import com.plexmc.boosters.calculation.MultiplierEngine;
import com.plexmc.boosters.persistence.SQLiteStore;
import com.plexmc.boosters.registry.RewardRegistry;

import java.math.BigDecimal;
import java.time.Clock;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Collectors;

public final class BoosterManager implements BoostersAPI, AutoCloseable {
    public static final String MODIFIER_ID = "boosters";
    private final SQLiteStore store;
    private final RewardRegistry registry;
    private final Clock clock;
    private final ExecutorService mutations;
    private final AtomicLong revision = new AtomicLong();
    private volatile Map<String, BoosterRecord> records = Map.of();
    private volatile StackingPolicy stackingPolicy;
    private volatile BigDecimal maxMultiplier;
    private volatile java.util.function.Function<String, PresetDefinition> presetResolver = id -> null;
    private final ConcurrentHashMap<CacheKey, CachedMultiplier> multiplierCache = new ConcurrentHashMap<>();

    public BoosterManager(SQLiteStore store, RewardRegistry registry, StackingPolicy policy, BigDecimal cap, Clock clock) throws Exception {
        this.store = Objects.requireNonNull(store);
        this.registry = Objects.requireNonNull(registry);
        this.stackingPolicy = Objects.requireNonNull(policy);
        this.maxMultiplier = Objects.requireNonNull(cap);
        this.clock = Objects.requireNonNull(clock);
        this.mutations = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "boosters-persistence");
            t.setDaemon(true);
            return t;
        });
        restore();
    }

    private void restore() throws Exception {
        long now = clock.millis();
        Map<String, BoosterRecord> loaded = new HashMap<>();
        for (BoosterRecord record : store.loadAll(now)) {
            if (record.state() == BoosterState.ACTIVE && record.expiresAt() != null && record.expiresAt() <= now) continue;
            loaded.put(record.identity(), record);
        }
        records = Map.copyOf(loaded);
    }

    public void setPolicy(StackingPolicy policy, BigDecimal cap) {
        this.stackingPolicy = Objects.requireNonNull(policy);
        this.maxMultiplier = validateCap(cap);
        invalidate();
    }

    public StackingPolicy policy() { return stackingPolicy; }
    public BigDecimal cap() { return maxMultiplier; }
    public RewardRegistry registry() { return registry; }
    public long revision() { return revision.get(); }
    public void setPresetResolver(java.util.function.Function<String, PresetDefinition> resolver) { this.presetResolver = Objects.requireNonNull(resolver); }

    @Override public BigDecimal multiplier(UUID player, String rewardType) {
        if (player == null) throw new IllegalArgumentException("player is required");
        String type = registry.canonical(rewardType);
        if (!registry.available(type)) return BigDecimal.ONE;
        long now = clock.millis();
        CacheKey key = new CacheKey(player, type);
        CachedMultiplier cached = multiplierCache.get(key);
        long currentRevision = revision.get();
        if (cached != null && cached.revision == currentRevision && (cached.expiresAt == null || cached.expiresAt > now)) {
            return cached.value;
        }
        List<BoosterRecord> applicable = applicable(player, type, now);
        List<BigDecimal> values = applicable.stream().map(BoosterRecord::multiplier).toList();
        BigDecimal effective = MultiplierEngine.effective(values, stackingPolicy, maxMultiplier);
        Long nextExpiry = applicable.stream().map(BoosterRecord::expiresAt).filter(Objects::nonNull).min(Long::compareTo).orElse(null);
        multiplierCache.put(key, new CachedMultiplier(currentRevision, effective, nextExpiry));
        return effective;
    }

    @Override public BigDecimal apply(UUID player, String rewardType, BigDecimal baseAmount) {
        if (baseAmount == null || baseAmount.signum() < 0) throw new IllegalArgumentException("baseAmount must be non-negative");
        return evaluate(new RewardContext(player, rewardType, baseAmount, "API", "API", null, true, Set.of())).adjustedAmount();
    }

    @Override public RewardEvaluation evaluate(RewardContext context) {
        String type = registry.canonical(context.rewardType());
        BigDecimal base = context.originalAmount();
        if (!context.eligible() || base.signum() <= 0 || context.hasModifier(MODIFIER_ID)) {
            return new RewardEvaluation(base, BigDecimal.ONE, base, false, Set.of());
        }
        BigDecimal multiplier = multiplier(context.player(), type);
        BigDecimal adjusted = MultiplierEngine.multiply(base, multiplier);
        Set<String> keys = applicable(context.player(), type, clock.millis()).stream()
                .map(BoosterRecord::identity).collect(Collectors.toUnmodifiableSet());
        return new RewardEvaluation(base, multiplier, adjusted, multiplier.compareTo(BigDecimal.ONE) != 0, keys);
    }

    @Override public CompletionStage<AssignmentResult> setPersonal(UUID player, String id, String type,
                                                                     BigDecimal multiplier, Duration duration) {
        return mutatePersonal(player, id, type, multiplier, duration, false);
    }

    @Override public CompletionStage<AssignmentResult> setPersonalPermanent(UUID player, String id, String type, BigDecimal multiplier) {
        return mutatePersonal(player, id, type, multiplier, null, false, true);
    }

    public CompletionStage<AssignmentResult> giveReady(UUID player, String id, String type, BigDecimal multiplier, Duration duration, boolean permanent) {
        return mutatePersonal(player, id, type, multiplier, permanent ? null : duration, true, false);
    }

    private CompletionStage<AssignmentResult> mutatePersonal(UUID player, String rawId, String rawType, BigDecimal value,
                                                              Duration duration, boolean ready) {
        return mutatePersonal(player, rawId, rawType, value, duration, ready, false);
    }

    private CompletionStage<AssignmentResult> mutatePersonal(UUID player, String rawId, String rawType, BigDecimal value,
                                                              Duration duration, boolean ready, boolean permanentActive) {
        String id; String type; BigDecimal multiplier;
        try {
            if (player == null) throw new IllegalArgumentException("player is required");
            id = normalizeId(rawId); type = registry.canonical(rawType); multiplier = validateMultiplier(value);
            if (!ready && duration == null && !permanentActive) throw new IllegalArgumentException("Timed duration is required");
            if (!ready && !permanentActive && (duration.isZero() || duration.isNegative())) throw new IllegalArgumentException("Duration must be positive");
        } catch (RuntimeException ex) { return CompletableFuture.completedFuture(AssignmentResult.failure(ex.getMessage())); }
        final String finalId = id, finalType = type; final BigDecimal finalMultiplier = multiplier;
        return submit(() -> {
            long now = clock.millis();
            String identity = player + ":" + finalType + ":" + finalId;
            BoosterRecord previous = records.get(identity);
            Long expires = null; Long durationMillis = ready || duration != null ? (duration == null ? null : duration.toMillis()) : null;
            Long activated = null;
            BoosterState state = ready ? BoosterState.READY : BoosterState.ACTIVE;
            if (!ready) {
                activated = now;
                expires = permanentActive ? null : expiration(now, duration);
            }
            BoosterRecord next = new BoosterRecord(player, false, finalType, finalId, finalMultiplier, state, now, activated, expires, durationMillis);
            store.upsertPersonal(next);
            publishReplacement(identity, next);
            return new AssignmentResult(true, previous != null, next.view(), previous == null ? "Assigned" : "Replaced existing assignment");
        });
    }

    @Override public CompletionStage<AssignmentResult> setGlobal(String id, String type, BigDecimal multiplier, Duration duration) {
        return mutateGlobal(id, type, multiplier, duration, false);
    }

    @Override public CompletionStage<AssignmentResult> setGlobalPermanent(String id, String type, BigDecimal multiplier) {
        return mutateGlobal(id, type, multiplier, null, true);
    }

    private CompletionStage<AssignmentResult> mutateGlobal(String rawId, String rawType, BigDecimal value, Duration duration, boolean permanent) {
        String id; String type; BigDecimal multiplier;
        try {
            id = normalizeId(rawId); type = registry.canonical(rawType); multiplier = validateMultiplier(value);
            if (!permanent && (duration == null || duration.isZero() || duration.isNegative())) throw new IllegalArgumentException("Duration must be positive");
        } catch (RuntimeException ex) { return CompletableFuture.completedFuture(AssignmentResult.failure(ex.getMessage())); }
        final String finalId=id, finalType=type; final BigDecimal finalMultiplier=multiplier;
        return submit(() -> {
            long now = clock.millis(); String identity = "global:" + finalType + ":" + finalId;
            BoosterRecord previous = records.get(identity);
            BoosterRecord next = new BoosterRecord(null, true, finalType, finalId, finalMultiplier, BoosterState.ACTIVE, now, now,
                    permanent ? null : expiration(now, duration), permanent ? null : duration.toMillis());
            store.upsertGlobal(next); publishReplacement(identity, next);
            return new AssignmentResult(true, previous != null, next.view(), previous == null ? "Assigned" : "Replaced existing assignment");
        });
    }

    @Override public CompletionStage<AssignmentResult> give(UUID player, String presetId) {
        try {
            PresetDefinition preset = presetResolver.apply(RewardRegistry.normalizeId(presetId));
            if (preset == null) return CompletableFuture.completedFuture(AssignmentResult.failure("Unknown preset: " + presetId));
            return givePreset(player, preset);
        } catch (RuntimeException ex) { return CompletableFuture.completedFuture(AssignmentResult.failure(ex.getMessage())); }
    }

    public CompletionStage<AssignmentResult> givePreset(UUID player, PresetDefinition preset) {
        return giveReady(player, preset.id(), preset.rewardType(), preset.multiplier(), preset.duration(), preset.permanent());
    }

    @Override public CompletionStage<Boolean> activateReady(UUID player, String rawType, String rawId) {
        final String id; final String type;
        try { id = normalizeId(rawId); type = registry.canonical(rawType); }
        catch (RuntimeException ex) { return CompletableFuture.completedFuture(false); }
        return submit(() -> {
            String identity = player + ":" + type + ":" + id;
            BoosterRecord existing = records.get(identity);
            if (existing == null || existing.state() != BoosterState.READY) return false;
            long now = clock.millis();
            BoosterRecord next = new BoosterRecord(player, false, type, id, existing.multiplier(), BoosterState.ACTIVE, existing.assignedAt(), now,
                    existing.durationMillis() == null ? null : expiration(now, Duration.ofMillis(existing.durationMillis())), existing.durationMillis());
            store.upsertPersonal(next); publishReplacement(identity, next); return true;
        });
    }

    @Override public CompletionStage<Boolean> removePersonal(UUID player, String rawType, String rawId) {
        return remove(player, rawType, rawId, false);
    }

    @Override public CompletionStage<Boolean> removeGlobal(String rawType, String rawId) {
        return remove(null, rawType, rawId, true);
    }

    private CompletionStage<Boolean> remove(UUID player, String rawType, String rawId, boolean global) {
        final String id; final String type;
        try { id=normalizeId(rawId); type=registry.canonical(rawType); }
        catch (RuntimeException ex) { return CompletableFuture.completedFuture(false); }
        return submit(() -> {
            String identity = (global ? "global" : player) + ":" + type + ":" + id;
            boolean existed = records.containsKey(identity);
            if (global) store.deleteGlobal(type, id); else store.deletePersonal(player, type, id);
            if (existed) { Map<String, BoosterRecord> copy = new HashMap<>(records); copy.remove(identity); records=Map.copyOf(copy); invalidate(); }
            return existed;
        });
    }

    @Override public List<BoosterView> personal(UUID player) {
        long now = clock.millis();
        return records.values().stream().filter(r -> !r.global() && player.equals(r.player()) && !isExpired(r, now)).map(BoosterRecord::view).toList();
    }

    @Override public List<BoosterView> global() {
        long now = clock.millis();
        return records.values().stream().filter(r -> r.global() && !isExpired(r, now)).map(BoosterRecord::view).toList();
    }

    @Override public CompletionStage<Boolean> registerRewardType(RewardTypeRegistration registration) {
        try { registry.register(registration); return CompletableFuture.completedFuture(true); }
        catch (RuntimeException ex) { return CompletableFuture.completedFuture(false); }
    }

    @Override public CompletionStage<Boolean> unregisterRewardType(String rewardType) {
        try { registry.unregister(rewardType); return CompletableFuture.completedFuture(true); }
        catch (RuntimeException ex) { return CompletableFuture.completedFuture(false); }
    }

    public void expireAndCleanup() {
        long now = clock.millis();
        mutations.submit(() -> {
            try {
                boolean changed = records.values().stream().anyMatch(r -> isExpired(r, now));
                store.cleanupExpired(now);
                if (changed) restoreAndInvalidate();
            } catch (Exception ignored) { }
        });
    }

    private boolean isExpired(BoosterRecord record, long now) { return record.state() == BoosterState.EXPIRED || (record.expiresAt() != null && record.expiresAt() <= now); }
    private List<BoosterRecord> applicable(UUID player, String type, long now) {
        return records.values().stream().filter(r -> r.rewardType().equals(type) && r.activeAt(now) && (r.global() || player.equals(r.player()))).toList();
    }
    private void publishReplacement(String identity, BoosterRecord next) {
        Map<String, BoosterRecord> copy = new HashMap<>(records); copy.put(identity, next); records=Map.copyOf(copy); invalidate();
    }
    private void restoreAndInvalidate() throws Exception { restore(); invalidate(); }
    private void invalidate() { revision.incrementAndGet(); multiplierCache.clear(); }
    private <T> CompletionStage<T> submit(Callable<T> callable) {
        CompletableFuture<T> future = new CompletableFuture<>();
        try { mutations.execute(() -> { try { future.complete(callable.call()); } catch (Throwable t) { future.completeExceptionally(t); } }); }
        catch (RejectedExecutionException ex) { future.completeExceptionally(new IllegalStateException("Boosters is shutting down", ex)); }
        return future;
    }
    private static String normalizeId(String raw) { return RewardRegistry.normalizeId(raw == null || raw.isBlank() ? "default" : raw); }
    private static BigDecimal validateMultiplier(BigDecimal value) {
        if (value == null || value.signum() <= 0 || value.scale() > 12 || value.precision() > 24 || value.compareTo(new BigDecimal("1000")) > 0) throw new IllegalArgumentException("Multiplier must be finite, positive, <=1000x, and max 12 decimal places");
        return value.stripTrailingZeros();
    }
    private static BigDecimal validateCap(BigDecimal value) { if (value == null || value.compareTo(BigDecimal.ONE)<0) throw new IllegalArgumentException("Cap must be >= 1"); return value; }
    private static Long expiration(long now, Duration duration) { try { return Math.addExact(now, duration.toMillis()); } catch (ArithmeticException ex) { throw new IllegalArgumentException("Duration is too large", ex); } }
    @Override public void close() throws Exception { mutations.shutdown(); if (!mutations.awaitTermination(10, TimeUnit.SECONDS)) mutations.shutdownNow(); store.close(); }

    public record PresetDefinition(String id, String rewardType, BigDecimal multiplier, Duration duration, boolean permanent) { }
    private record CacheKey(UUID player, String type) { }
    private static final class CachedMultiplier { private final long revision; private final BigDecimal value; private final Long expiresAt; private CachedMultiplier(long revision, BigDecimal value, Long expiresAt) { this.revision=revision; this.value=value; this.expiresAt=expiresAt; } }
}

