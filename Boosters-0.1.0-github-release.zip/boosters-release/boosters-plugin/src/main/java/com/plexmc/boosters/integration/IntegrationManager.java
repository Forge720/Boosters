package com.plexmc.boosters.integration;

import com.plexmc.boosters.api.CurrencyBridge;
import com.plexmc.boosters.booster.BoosterManager;
import org.bukkit.Bukkit;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

public final class IntegrationManager {
    private final JavaPlugin plugin;
    private final BoosterManager manager;
    private volatile boolean currencyAvailable;
    private volatile boolean vaultAvailable;

    public IntegrationManager(JavaPlugin plugin, BoosterManager manager) { this.plugin=plugin; this.manager=manager; }

    public void refresh() {
        CurrencyBridge bridge = nativeCurrencyBridge();
        if (bridge == null) {
            RegisteredServiceProvider<CurrencyBridge> registration = Bukkit.getServicesManager().getRegistration(CurrencyBridge.class);
            bridge = registration == null ? null : registration.getProvider();
        }
        currencyAvailable = bridge != null && bridge.available();
        vaultAvailable = false;
        if (Bukkit.getPluginManager().getPlugin("Vault") != null) {
            try {
                Class<?> economy = Class.forName("net.milkbowl.vault.economy.Economy");
                vaultAvailable = Bukkit.getServicesManager().getRegistration(economy) != null;
            } catch (ClassNotFoundException ignored) { }
        }
        manager.registry().refreshCurrencyBridge(bridge);
    }

    public boolean currencyAvailable() { return currencyAvailable; }
    public boolean vaultAvailable() { return vaultAvailable; }
    public String status() { return "Currency.jar=" + (currencyAvailable ? "available" : "unavailable") + ", Vault=" + (vaultAvailable ? "available" : "not detected"); }

    private CurrencyBridge nativeCurrencyBridge() {
        if (!Bukkit.getPluginManager().isPluginEnabled("Currency")) return null;
        try {
            Object integration = Class.forName("com.plexmc.boosters.integration.CurrencyApiIntegration")
                    .getDeclaredConstructor().newInstance();
            return (CurrencyBridge) integration;
        } catch (ReflectiveOperationException | LinkageError ignored) {
            return null;
        }
    }
}

