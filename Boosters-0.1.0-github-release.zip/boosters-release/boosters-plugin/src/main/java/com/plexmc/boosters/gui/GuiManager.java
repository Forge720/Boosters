package com.plexmc.boosters.gui;

import com.plexmc.boosters.api.BoosterState;
import com.plexmc.boosters.api.BoosterView;
import com.plexmc.boosters.booster.BoosterManager;
import com.plexmc.boosters.config.PresetRegistry;
import com.plexmc.boosters.integration.IntegrationManager;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.math.BigDecimal;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

public final class GuiManager implements Listener {
    private final JavaPlugin plugin; private final BoosterManager manager; private final PresetRegistry presets; private final IntegrationManager integrations;
    private final NamespacedKey actionKey, typeKey, idKey; private final Map<UUID, ChatPrompt> prompts=new ConcurrentHashMap<>();

    public GuiManager(JavaPlugin plugin, BoosterManager manager, PresetRegistry presets, IntegrationManager integrations) {
        this.plugin=plugin; this.manager=manager; this.presets=presets; this.integrations=integrations;
        actionKey=new NamespacedKey(plugin,"action"); typeKey=new NamespacedKey(plugin,"type"); idKey=new NamespacedKey(plugin,"id");
    }

    public void openPlayer(Player player) {
        Inventory inv=Bukkit.createInventory(new MenuHolder(player.getUniqueId(),false),27,"Boosters"); int ready=0, active=9, global=18;
        for(BoosterView view:manager.personal(player.getUniqueId())) {
            if(view.state()==BoosterState.READY && ready<9) inv.setItem(ready++, item(Material.CHEST,"§aREADY §f"+view.rewardType()+" §7"+view.multiplier()+"x", "activate", view));
            else if(view.state()==BoosterState.ACTIVE && active<18) inv.setItem(active++, item(Material.NETHER_STAR,"§bACTIVE §f"+view.rewardType()+" §7"+view.multiplier()+"x", "noop", view));
        }
        for(BoosterView view:manager.global()) if(global<27) inv.setItem(global++, item(Material.BEACON,"§dGLOBAL §f"+view.rewardType()+" §7"+view.multiplier()+"x", "noop", view));
        player.openInventory(inv);
    }

    public void openAdmin(Player player) {
        Inventory inv=Bukkit.createInventory(new MenuHolder(player.getUniqueId(),true),27,"Boosters Admin");
        inv.setItem(0, button(Material.EMERALD,"§aCreate preset","create")); inv.setItem(1,button(Material.BOOK,"§eEdit preset","edit")); inv.setItem(2,button(Material.BARRIER,"§cDelete preset","delete"));
        inv.setItem(3,button(Material.CHEST,"§bAssign personal","assign")); inv.setItem(4,button(Material.BEACON,"§dActivate global","global")); inv.setItem(5,button(Material.PAPER,"§fInspect player","inspect"));
        inv.setItem(6,button(Material.TNT,"§cRemove assignment","remove")); inv.setItem(7,button(Material.REDSTONE,"§fIntegration status","status")); inv.setItem(8,button(Material.CLOCK,"§fReload","reload"));
        int slot=9; for(BoosterManager.PresetDefinition p:presets.all().values()) if(slot<27) inv.setItem(slot++,button(Material.NAME_TAG,"§fPreset: §e"+p.id(),"preset:"+p.id()));
        player.openInventory(inv);
    }

    private ItemStack button(Material material,String name,String action){ItemStack item=new ItemStack(material);ItemMeta meta=item.getItemMeta();meta.setDisplayName(name);meta.getPersistentDataContainer().set(actionKey,PersistentDataType.STRING,action);item.setItemMeta(meta);return item;}
    private ItemStack item(Material material,String name,String action,BoosterView view){ItemStack item=button(material,name,action);ItemMeta m=item.getItemMeta();m.getPersistentDataContainer().set(typeKey,PersistentDataType.STRING,view.rewardType());m.getPersistentDataContainer().set(idKey,PersistentDataType.STRING,view.id());item.setItemMeta(m);return item;}

    @EventHandler public void onClick(InventoryClickEvent event){
        if(!(event.getView().getTopInventory().getHolder() instanceof MenuHolder holder))return; event.setCancelled(true); if(!(event.getWhoClicked() instanceof Player player))return;
        ItemStack clicked=event.getCurrentItem();if(clicked==null||!clicked.hasItemMeta())return;String action=clicked.getItemMeta().getPersistentDataContainer().get(actionKey,PersistentDataType.STRING);if(action==null)return;
        if(!holder.admin){ if(action.equals("activate")){String type=clicked.getItemMeta().getPersistentDataContainer().get(typeKey,PersistentDataType.STRING),id=clicked.getItemMeta().getPersistentDataContainer().get(idKey,PersistentDataType.STRING);player.closeInventory();manager.activateReady(player.getUniqueId(),type,id).whenComplete((ok,err)->Bukkit.getScheduler().runTask(plugin,()->{if(err!=null||!Boolean.TRUE.equals(ok))player.sendMessage("§cThat booster is no longer READY.");else player.sendMessage("§aBooster activated.");openPlayer(player);}));} return; }
        if(!player.hasPermission("boosters.admin")) { player.closeInventory(); return; }
        player.closeInventory();
        switch(action){case "create"->prompt(player,"Enter: <id> <type> <multiplier> <duration|permanent>",input->create(player,input));case "edit"->prompt(player,"Enter: <id> <type> <multiplier> <duration|permanent>",input->create(player,input));case "delete"->prompt(player,"Enter preset ID",input->delete(player,input));case "assign"->prompt(player,"Enter: <uuid> <preset>",input->assign(player,input));case "global"->prompt(player,"Enter: <type> <multiplier> <duration|permanent> [id]",input->global(player,input));case "inspect"->prompt(player,"Enter player UUID",input->inspect(player,input));case "remove"->prompt(player,"Enter: <uuid|global> <type> <id>",input->remove(player,input));case "status"->player.sendMessage("§f"+integrations.status());case "reload"->plugin.getCommand("boost").execute(player,"boost",new String[]{"reload"});default->{} }
    }

    @EventHandler public void onClose(InventoryCloseEvent event){if(event.getPlayer() instanceof Player p && event.getView().getTopInventory().getHolder() instanceof MenuHolder){} }
    @EventHandler public void onChat(AsyncPlayerChatEvent event){ChatPrompt prompt=prompts.get(event.getPlayer().getUniqueId());if(prompt==null)return;event.setCancelled(true);if(System.currentTimeMillis()>prompt.deadline){prompts.remove(event.getPlayer().getUniqueId());event.getPlayer().sendMessage("§cInput timed out.");return;}prompts.remove(event.getPlayer().getUniqueId());String input=event.getMessage();Bukkit.getScheduler().runTask(plugin,()->prompt.handler.accept(input));}
    private void prompt(Player player,String message,Consumer<String> handler){prompts.put(player.getUniqueId(),new ChatPrompt(System.currentTimeMillis()+60_000,handler));player.sendMessage("§e"+message+" §7(type cancel to cancel)");}
    private void create(Player admin,String input){if(input.equalsIgnoreCase("cancel")){admin.sendMessage("§7Cancelled.");return;}String[] p=input.split("\\s+");if(p.length!=4){admin.sendMessage("§cExpected four values.");return;}try{BigDecimal mult=PresetRegistry.parseMultiplier(p[2]);boolean perm=p[3].equalsIgnoreCase("permanent");Duration d=perm?null:PresetRegistry.parseDuration(p[3]);presets.savePreset(new BoosterManager.PresetDefinition(p[0],p[1],mult,d,perm));admin.sendMessage("§aPreset saved.");}catch(Exception ex){admin.sendMessage("§c"+ex.getMessage());}}
    private void delete(Player admin,String input){try{presets.delete(input.trim());admin.sendMessage("§aPreset deleted.");}catch(Exception ex){admin.sendMessage("§c"+ex.getMessage());}}
    private void assign(Player admin,String input){String[] p=input.split("\\s+");if(p.length!=2){admin.sendMessage("§cExpected UUID and preset.");return;}try{UUID u=UUID.fromString(p[0]);var preset=presets.get(p[1]);if(preset==null)throw new IllegalArgumentException("Unknown preset");manager.givePreset(u,preset).whenComplete((r,e)->Bukkit.getScheduler().runTask(plugin,()->admin.sendMessage(e!=null?"§c"+e.getMessage():"§a"+r.message())));}catch(Exception ex){admin.sendMessage("§c"+ex.getMessage());}}
    private void global(Player admin,String input){String[] p=input.split("\\s+");if(p.length<3||p.length>4){admin.sendMessage("§cExpected type multiplier duration [id].");return;}try{BigDecimal m=PresetRegistry.parseMultiplier(p[1]);boolean perm=p[2].equalsIgnoreCase("permanent");Duration d=perm?null:PresetRegistry.parseDuration(p[2]);var f=perm?manager.setGlobalPermanent(p.length==4?p[3]:"default",p[0],m):manager.setGlobal(p.length==4?p[3]:"default",p[0],m,d);f.whenComplete((r,e)->Bukkit.getScheduler().runTask(plugin,()->admin.sendMessage(e!=null?"§c"+e.getMessage():"§a"+r.message())));}catch(Exception ex){admin.sendMessage("§c"+ex.getMessage());}}
    private void inspect(Player admin,String input){try{UUID u=UUID.fromString(input.trim());admin.sendMessage("§fPersonal boosters for "+u+":");manager.personal(u).forEach(v->admin.sendMessage("§7- "+v.rewardType()+" "+v.id()+" "+v.multiplier()+"x "+v.state()));}catch(Exception ex){admin.sendMessage("§cInvalid UUID.");}}
    private void remove(Player admin,String input){String[] p=input.split("\\s+");if(p.length!=3){admin.sendMessage("§cExpected UUID|global type id.");return;}try{boolean global=p[0].equalsIgnoreCase("global");var f=global?manager.removeGlobal(p[1],p[2]):manager.removePersonal(UUID.fromString(p[0]),p[1],p[2]);f.whenComplete((ok,e)->Bukkit.getScheduler().runTask(plugin,()->admin.sendMessage(e!=null?"§c"+e.getMessage():Boolean.TRUE.equals(ok)?"§aRemoved.":"§cNot found.")));}catch(Exception ex){admin.sendMessage("§c"+ex.getMessage());}}
    public void closeAll(){prompts.clear();for(Player p:Bukkit.getOnlinePlayers())if(p.getOpenInventory().getTopInventory().getHolder() instanceof MenuHolder)p.closeInventory();}
    private record ChatPrompt(long deadline,Consumer<String> handler){}
    private record MenuHolder(UUID owner,boolean admin) implements InventoryHolder{public Inventory getInventory(){return null;}}
}

