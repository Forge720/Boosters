package com.plexmc.boosters.calculation;

import com.plexmc.boosters.api.StackingPolicy;
import com.plexmc.boosters.booster.BoosterManager;
import com.plexmc.boosters.persistence.SQLiteStore;
import com.plexmc.boosters.registry.RewardRegistry;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.nio.file.Files;
import java.time.*;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

class BoosterManagerTest {
    @Test void sameIdentityReplacesAndDoesNotStack() throws Exception {
        MutableClock clock=new MutableClock(); UUID player=UUID.randomUUID();
        try(BoosterManager manager=new BoosterManager(new SQLiteStore(Files.createTempDirectory("boosters")),new RewardRegistry(),StackingPolicy.HIGHEST,new BigDecimal("1000"),clock)) {
            manager.setPersonal(player,"rank","money",new BigDecimal("2"),Duration.ofMinutes(30)).toCompletableFuture().join();
            clock.advance(Duration.ofMinutes(5));
            var result=manager.setPersonal(player,"rank","money",new BigDecimal("3"),Duration.ofHours(1)).toCompletableFuture().join();
            assertTrue(result.replaced()); assertEquals(new BigDecimal("3"),manager.multiplier(player,"money")); assertEquals(1,manager.personal(player).size());
        }
    }
    @Test void readyActivatesOnceAndGlobalStacks() throws Exception {
        MutableClock clock=new MutableClock(); UUID player=UUID.randomUUID();
        try(BoosterManager manager=new BoosterManager(new SQLiteStore(Files.createTempDirectory("boosters")),new RewardRegistry(),StackingPolicy.ADDITIVE,new BigDecimal("1000"),clock)) {
            manager.giveReady(player,"event","money",new BigDecimal("2"),Duration.ofHours(1),false).toCompletableFuture().join();
            assertEquals(BigDecimal.ONE,manager.multiplier(player,"money"));
            assertTrue(manager.activateReady(player,"money","event").toCompletableFuture().join());
            assertFalse(manager.activateReady(player,"money","event").toCompletableFuture().join());
            manager.setGlobal("global","money",new BigDecimal("3"),Duration.ofHours(1)).toCompletableFuture().join();
            assertEquals(new BigDecimal("4"),manager.multiplier(player,"money"));
            clock.advance(Duration.ofHours(2)); assertEquals(BigDecimal.ONE,manager.multiplier(player,"money"));
        }
    }
    @Test void activeStateRestoresAcrossManagerRestart() throws Exception {
        MutableClock clock=new MutableClock(); UUID player=UUID.randomUUID(); var folder=Files.createTempDirectory("boosters-restart");
        try (BoosterManager first=new BoosterManager(new SQLiteStore(folder),new RewardRegistry(),StackingPolicy.HIGHEST,new BigDecimal("1000"),clock)) {
            first.setPersonal(player,"restart","money",new BigDecimal("2.5"),Duration.ofHours(1)).toCompletableFuture().join();
        }
        clock.advance(Duration.ofMinutes(10));
        try (BoosterManager second=new BoosterManager(new SQLiteStore(folder),new RewardRegistry(),StackingPolicy.HIGHEST,new BigDecimal("1000"),clock)) {
            assertEquals(new BigDecimal("2.5"),second.multiplier(player,"money"));
            assertEquals(1,second.personal(player).size());
        }
    }
    @Test void unavailableCurrencyDoesNotEvaluateUntilBridgeAppears() throws Exception {
        MutableClock clock=new MutableClock(); UUID player=UUID.randomUUID(); var registry=new RewardRegistry(); var folder=Files.createTempDirectory("boosters-currency");
        try (BoosterManager manager=new BoosterManager(new SQLiteStore(folder),registry,StackingPolicy.HIGHEST,new BigDecimal("1000"),clock)) {
            manager.setPersonal(player,"tokens","currency:tokens",new BigDecimal("2"),Duration.ofHours(1)).toCompletableFuture().join();
            assertEquals(BigDecimal.ONE,manager.multiplier(player,"currency:tokens"));
            registry.refreshCurrencyBridge(new com.plexmc.boosters.api.CurrencyBridge(){public String primaryCurrencyId(){return "money";}public java.util.Set<String> registeredCurrencyIds(){return java.util.Set.of("tokens");}public boolean available(){return true;}});
            assertEquals(new BigDecimal("2"),manager.multiplier(player,"currency:tokens"));
        }
    }
    @Test void permanentPersonalAssignmentIsValid() throws Exception {
        MutableClock clock=new MutableClock(); UUID player=UUID.randomUUID();
        try (BoosterManager manager=new BoosterManager(new SQLiteStore(Files.createTempDirectory("boosters-permanent")),new RewardRegistry(),StackingPolicy.HIGHEST,new BigDecimal("1000"),clock)) {
            var result=manager.setPersonalPermanent(player,"rank","money",new BigDecimal("2")).toCompletableFuture().join();
            assertTrue(result.success()); assertNull(result.booster().expiresAt()); assertEquals(new BigDecimal("2"),manager.multiplier(player,"money"));
        }
    }
    private static final class MutableClock extends Clock { private Instant now=Instant.parse("2026-01-01T00:00:00Z"); void advance(Duration d){now=now.plus(d);} public ZoneId getZone(){return ZoneOffset.UTC;} public Clock withZone(ZoneId z){return this;} public Instant instant(){return now;} }
}

