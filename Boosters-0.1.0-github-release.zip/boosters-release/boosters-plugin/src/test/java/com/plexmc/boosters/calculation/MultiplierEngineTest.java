package com.plexmc.boosters.calculation;

import com.plexmc.boosters.api.StackingPolicy;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class MultiplierEngineTest {
    private static BigDecimal n(String value) { return new BigDecimal(value); }
    @Test void policiesAreExact() {
        assertEquals(n("3"),MultiplierEngine.effective(List.of(n("2"),n("3")),StackingPolicy.HIGHEST,n("1000")));
        assertEquals(n("4"),MultiplierEngine.effective(List.of(n("2"),n("3")),StackingPolicy.ADDITIVE,n("1000")));
        assertEquals(n("6"),MultiplierEngine.effective(List.of(n("2"),n("3")),StackingPolicy.MULTIPLICATIVE,n("1000")));
    }
    @Test void capDoesNotMutateInputs() { assertEquals(n("5"),MultiplierEngine.effective(List.of(n("2"),n("3")),StackingPolicy.MULTIPLICATIVE,n("5"))); }
}

