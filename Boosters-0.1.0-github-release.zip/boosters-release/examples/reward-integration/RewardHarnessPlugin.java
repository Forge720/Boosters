package com.plexmc.boosters.example;

import com.plexmc.boosters.api.BoostersAPI;
import com.plexmc.boosters.api.RewardContext;
import com.plexmc.boosters.integration.CurrencyRewardAdapter;
import net.plexmc.currency.api.CurrencyService;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.math.BigDecimal;
import java.util.Set;
import java.util.UUID;

/** Disposable live-test producer. It models the exact first-party reward flow. */
public final class RewardHarnessPlugin extends JavaPlugin implements CommandExecutor {
    @Override public void onEnable() { getCommand("rewardtest").setExecutor(this); }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player) || args.length < 3) {
            sender.sendMessage("/rewardtest <currency-id> <amount> <operation-id>"); return true;
        }
        try {
            String id=args[0].toLowerCase(); BigDecimal base=new BigDecimal(args[1]); String operationId=args[2];
            BoostersAPI boosters=Bukkit.getServicesManager().load(BoostersAPI.class);
            CurrencyService currency=Bukkit.getServicesManager().load(CurrencyService.class);
            if(boosters==null||currency==null){sender.sendMessage("SERVICES_UNAVAILABLE");return true;}
            RewardContext context=new RewardContext(player.getUniqueId(), id.equals("money")?"money":"currency:"+id,
                    base,"RewardHarness","TEST_REWARD",operationId,true,Set.of());
            CurrencyRewardAdapter.creditEligible(currency,boosters,context,operationId,"RewardHarness","TEST_REWARD")
                    .whenComplete((result,error)->Bukkit.getScheduler().runTask(this,()->sender.sendMessage(error==null
                            ? "REWARD_RESULT status="+result.status()+" operation="+result.operationId()
                            : "REWARD_ERROR "+error.getMessage())));
        } catch (Exception exception) { sender.sendMessage("REWARD_ERROR "+exception.getMessage()); }
        return true;
    }
}

