package example;

import com.plexmc.boosters.api.BoostersAPI;
import com.plexmc.boosters.api.RewardContext;
import org.bukkit.Bukkit;

import java.math.BigDecimal;
import java.util.Set;
import java.util.UUID;

/** Illustrative producer pattern: calculate once, then commit once in Currency.jar. */
public final class ExampleRewardProducer {
    public BigDecimal adjustedMoney(UUID player, BigDecimal earned) {
        var provider=Bukkit.getServicesManager().getRegistration(BoostersAPI.class);
        if(provider==null) return earned;
        BoostersAPI api=provider.getProvider();
        return api.evaluate(new RewardContext(player,"money",earned,"Mines.jar","MINING",null,true,Set.of())).adjustedAmount();
    }
}

