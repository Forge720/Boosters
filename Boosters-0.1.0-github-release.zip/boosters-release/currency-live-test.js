const mineflayer=require('/workspace/scratch/7d7eccdfeebb/integration-client/node_modules/mineflayer');
const bot=mineflayer.createBot({host:'127.0.0.1',port:Number(process.env.MC_PORT||25579),username:'BoostersTester',auth:'offline',version:'1.21.8'});
const messages=[];let failed=false;let windows=0;
bot.on('messagestr',m=>{messages.push(m);console.log('[CHAT]',m)});
bot.on('windowOpen',w=>{windows++;console.log('[WINDOW]',w.slots.length,w.slots.slice(0,27).map((x,i)=>x?`${i}:${x.name}`:null).filter(Boolean).join('|'))});
const wait=ms=>new Promise(r=>setTimeout(r,ms));const chat=x=>{console.log('[COMMAND]',x);bot.chat(x)};
async function expect(re,ms=7000){let end=Date.now()+ms;while(Date.now()<end){if(messages.some(m=>re.test(m)))return true;await wait(100)}console.error('[ASSERT]',re);failed=true;return false}
bot.once('spawn',async()=>{await wait(1200);
 chat('/boost set BoostersTester currency:coins 2x permanent coinboost');await expect(/Assigned/);
 chat('/boost set BoostersTester currency:coins 3x permanent coinboost');await expect(/Replaced/);
 chat('/boost list');await expect(/currency:coins.*coinboost.*3/);
 chat('/currency give BoostersTester coins 100');await expect(/give 100 coins committed/i);
 chat('/currency balance BoostersTester coins');await expect(/100/);
 chat('/rewardtest coins 10 reward-1');await expect(/REWARD_RESULT status=SUCCESS/);
 chat('/currency balance BoostersTester coins');await expect(/130/);
 chat('/rewardtest coins 10 reward-1');await expect(/REWARD_RESULT status=SUCCESS/);
 chat('/currency balance BoostersTester coins');await expect(/130/);
 chat('/boost admin');await wait(1000);if(windows<1)failed=true;else{await bot.clickWindow(7,0,0);await expect(/Currency\.jar=available/)}
 chat('/boost');await wait(800);if(windows<2)failed=true;
 console.log('[RESULT]',failed?'FAIL':'PASS');bot.quit();setTimeout(()=>process.exit(failed?1:0),500);
});
bot.on('kicked',r=>{console.error('[KICKED]',r);failed=true});bot.on('error',e=>{console.error('[ERROR]',e);failed=true});

